package com.example.recyclerviewproject;

public class ExempleItem {
    private int nota;
    private String nume;

    public ExampleItem(int no, String nu){
        nota = no;
        nume = nu;
    }

    public String getNume() {
        return nume;
    }

    public int getNota() {
        return nota;
    }
}
